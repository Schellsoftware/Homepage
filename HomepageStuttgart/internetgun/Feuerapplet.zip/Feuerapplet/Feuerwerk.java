import java.applet.Applet;
import java.awt.Button;
import java.awt.Color;
import java.awt.Event;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;



/**
 * @author Harald Schellinger
 *
 */

public class Feuerwerk extends Applet implements Runnable{

	boolean bild_gueltig=false; //Schaltet die Bilderazeige ein
	Button Feuer_frei; // Startdr�cker f�r das Feuerwerk
	int zaehler=1;//Z�hler f�r die Bildersequenz
	boolean bumm=false;//Start f�r das Feuerwerk
	Image  bilder[] = new Image[13]; //Bilder die in der Animation gezeigt werden
	private Thread	 m_thread = null;//Ablauf starten
	
	public void init(){//Initialisierungsroutine
		setLayout(null);//Anordnung der Steuerelemente
    	setBackground(new Color(230,230,230));//Hintergrundfarbe einstellen
        setSize(340,290);//Gr��e des Applets festlegen
        Feuer_frei = new Button("Starte Feuerwerk");//Startdr�cker erzeugen und beschriften
        Feuer_frei.setBounds(100,10,120,20);//Lage des Startdr�ckers festlegen
		add(Feuer_frei);//Startdr�cker hinzuf�gen
		MediaTracker mt = new MediaTracker(this);//Ladeassistent erzeugen
		for(int i=1;i<13;i++){
		  bilder[i] = getImage(getCodeBase(),"bild"+i+".jpg");//Bilder laden
		  mt.addImage(bilder[i],i);//Bilder zum Ladeassistent hinzuf�gen
		}
		try {
			mt.waitForAll();//Auf die Bilder warten
			bild_gueltig=true;//Bilder k�nnen angezeigt werden
		} catch (InterruptedException e){
			;
		}
	}
	public void paint(Graphics g){
		if(bild_gueltig){
			g.drawImage(bilder[zaehler],10,40,this);//Bilder anzeigen
		}
		else g.drawString("Bilder werden noch geladen",10,100);
	}
	public void run(){
		try{

		    while(true){
		    	if(bumm){//Feuerwerk gestartet?
		    		zaehler++;//Bildersequenz hochz�hlen
		    		if(zaehler>12){//Bildersequenz fertig?
		    			zaehler=1;//Anfangsbild w�hlen
		    			bumm=false;//Feuerwerk ist aus
		    		}
		    	}
		    	Thread.sleep(1000);//Wartezeit festlegen
			    repaint();//Neu zeichnen
		    }
		}
		catch (Exception e){
			
		}
	}
	public boolean action(Event event, Object eventObject){
		if ((event.target == Feuer_frei)){//Feuerwerksdr�cker gedr�ckt?
	    	bumm=true;//Feuerwerk starten
			return true;
		}
		else return false;
	}
	public void start()
	{
		if (m_thread == null)
		{
			m_thread = new Thread(this);//Thread erzeugen
			m_thread.start();//Thread starten
		}
	}
	public void stop()
	{
		if (m_thread != null)
		{
			m_thread.stop();//Thread stoppen
			m_thread = null;//Thread beenden
		}
	} 
}
