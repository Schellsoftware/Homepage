import java.awt.Button;
import java.awt.Color;
import java.awt.Event;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.net.Socket;

import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGEncodeParam;
import com.sun.image.codec.jpeg.JPEGImageDecoder;
import com.sun.image.codec.jpeg.JPEGImageEncoder;


/**
 * @author Harald Schellinger
 *
 */

public class Feuerwerk extends Frame implements Runnable{

	boolean bildgueltig=false;//Bild geladen?
	BufferedImage buffImg;// gepufferter Bildspeicher
	Socket s; //Verbindugssocket der den Datenstrom aufnimmt
	PrintWriter out;//Ausgabe in den Stream
	JPEGImageDecoder dec;//Jpeg decoder
	Button Feuer_frei;//Startdr�cker
	int zaehl=0;//Z�hler f�r die Bilder
	boolean bumm=false;//Feuerwerksschalter
	
	public Feuerwerk(){
		setLayout(null);//Kein Layout ausgew�hlt
    	setBackground(new Color(230,230,230));//Hintergrundfarbe w�hlen
        setSize(340,310);//Gr��e festelgen
        setVisible(true);//Sichtbar
        Feuer_frei = new Button("Starte Feuerwerk");//Startdr�cker beschriften
        Feuer_frei.setBounds(100,35,120,20);//Position des Startdr�ckers festlegen
		add(Feuer_frei);//Startdr�cker zum Layout hinzuf�gen
		addWindowListener( new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);//Beenden des Dialogs 
            }
        } );
	}
	public void paint(Graphics g){
		Graphics2D g2d = (Graphics2D) g;
		if(bildgueltig){
			g2d.drawImage(buffImg,10,60,this);//Bild zeichnen
		}
	}
	public void run(){
		try{

		    while(true){					
	        	s = new Socket("84.57.158.209",8189);//Socket mit der Internetadresse und Port starten
			    out = new PrintWriter(s.getOutputStream(),true);//Ausgabestrom initialisieren
			    if(bumm){//Feuerwerk gestartet?
			    	out.println("Hasta la vista");//Feuer frei
			    	bumm=false;//Wieder ausschalten
			    }
			    else out.println("Warte");//Warte mit dem Feuerwerk
			    dec = JPEGCodec.createJPEGDecoder( s.getInputStream() );//Decodieren des JPG
			    buffImg=dec.decodeAsBufferedImage();//Bild erzeugen
				bildgueltig=true;//Bild g�ltig
				//Bild speichern
				/*File datei = new File("K:\\programmieren\\bild"+zaehl+".jpg");
				zaehl++;
				JPEGImageEncoder enc = JPEGCodec.createJPEGEncoder( new FileOutputStream(datei));				
			    JPEGEncodeParam  prm = enc.getDefaultJPEGEncodeParam( buffImg );
				prm.setQuality( 1.0f, false );
				enc.setJPEGEncodeParam( prm );
				enc.encode( buffImg );*/
			    repaint();//Neu zeichnen
		    }
		}
		catch (Exception e){
			
		}
	}
	public boolean action(Event event, Object eventObject){
		if ((event.target == Feuer_frei)){//Startdr�cker gedr�ckt?
	    	bumm=true;//Feuerwerk starten
			return true;
		}
		else return false;
	}
	public static void main(String[] args) {
		Feuerwerk feuer = new Feuerwerk();//Objekt Feuerwerk starten
		feuer.run();//Start
	}   
}
