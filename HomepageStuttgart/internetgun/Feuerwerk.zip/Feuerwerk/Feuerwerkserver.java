import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

import javax.media.Buffer;
import javax.media.CaptureDeviceInfo;
import javax.media.CaptureDeviceManager;
import javax.media.Manager;
import javax.media.Player;
import javax.media.control.FrameGrabbingControl;
import javax.media.format.VideoFormat;
import javax.media.util.BufferToImage;

import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGEncodeParam;
import com.sun.image.codec.jpeg.JPEGImageEncoder;



/**
 * @author Harald Schellinger
 *
 */
public class Feuerwerkserver extends Thread{
	Image img;//Bild das geladen wird
	FrameGrabbingControl frameGrabber;//Bildschnapper
	ServerSocket ss; //Serversocket f�r den Datenstrom
	boolean res = false; int R;
	ftcomputing.JavaFish ft = new ftcomputing.JavaFish(3);//Schnittstelle zum Fischertechnik interface

	public Feuerwerkserver()
	{
		ft.setAnalogScan(true);//Scanner starten
		System.out.println("Versionsnr : " + ft.getVersion());
		R = ft.openInterface("COM1");
		System.out.println("OpenStatus : " + R);
		ft.showStatus();
		try{
			ss =new ServerSocket(8189);//Serversocket mit Portnummer 
			
		    // Create capture device
		    CaptureDeviceInfo deviceInfo = CaptureDeviceManager.getDevice("vfw:Microsoft WDM Image Capture (Win32):0");//Datenstrom anzapfen
		    Player player = Manager.createRealizedPlayer(deviceInfo.getLocator());//Filmplayer
		    player.start();//Filmplayer starten
		
		    // Wait a few seconds for camera to initialise (otherwise img==null)
		    sleep(2500);
		
		    // Grab a frame from the capture device
		    frameGrabber = (FrameGrabbingControl)player.getControl("javax.media.control.FrameGrabbingControl");
		}
		catch(Exception e){
			System.out.print(e);    
		}
	}
	public void run(){
		try{
		    while(true){
				Socket s= ss.accept();//Auf Datenstr�me warten
				JPEGImageEncoder enc = JPEGCodec.createJPEGEncoder( s.getOutputStream() );//Die Ausgabedaten werden jpg komprimiert
			    Buffer buf = frameGrabber.grabFrame();//Bilder grabben
			    sleep(100);//Warten
			    BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));//Eingangsstrom aufnehmen
			    if((in.readLine()).compareTo("Hasta la vista")==0){//Feuerwerk starten?
			    	ft.setMotor(3,1);//Motor starten
			    }
			    //System.out.println(in.readLine());
			    img = (new BufferToImage((VideoFormat)buf.getFormat()).createImage(buf));//Bild erzeugen
			    BufferedImage buffImg = new BufferedImage(img.getWidth(null), img.getHeight(null),  BufferedImage.TYPE_INT_RGB );//gepuffertes Bild erzeugen
			    Graphics2D g = buffImg.createGraphics();//Grafik erzeugen 
			    g.drawImage(img, null, null);//Bild speichern				
			    JPEGEncodeParam  prm = enc.getDefaultJPEGEncodeParam( buffImg );//Bild in jpeg wandel
				prm.setQuality( 1.0f, false );//Qualit�t festlegen
				enc.setJPEGEncodeParam( prm );//Kodierparameter festlegen
				enc.encode( buffImg );//Bild kodieren
		    }
		}
		catch (Exception e){
			System.out.print(e);
		}
	}
	public static void main(String[] args) {

		Feuerwerkserver feuerserver = new Feuerwerkserver();//Feuerwerksserver erzeugen
		feuerserver.run();//Feuerwerksserver starten
	}
}
