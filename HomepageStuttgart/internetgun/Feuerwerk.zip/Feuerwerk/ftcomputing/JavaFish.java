package ftcomputing;

/**
  * <h1>Steuerung der FischerTechnik Interfaces.</h1>
  * Die Klasse JavaFish erm&ouml;glicht &uuml;ber eine gr&ouml;&szlig;ere Anzahl
  * von Methoden und Eigenschaften den Zugriff auf die FischerTechnik Interfaces.
  * <code>JavaFish</code> nutzt die javaspezifische Wrapper-DLL
  * <code>javaFish.DLL</code>, der eigentliche Interface-Zugriff geschieht
  * &uuml;ber die <code>umFish20.DLL</code>. Um zuverl&auml;ssig alle
  * Ver&auml;nderungen der E-Eing&auml;nge mitzubekommen pollt
  * <code>umFish20</code> (&uuml;ber den MultiMediaTimer) mit hoher
  * Priorit&auml;t in ca. 10 msec Abst&auml;nden die E-Eing&auml;nge, macht
  * dabei gleichzeitig ein Refresh der M-Ausg&auml;nge und lie&szlig;t bei
  * Bedarf auch die A-Eing&auml;nge ein. Die Zust&auml;nde werden in einem
  * internen Kontrollblock gespeichert (er kann bei der Instanzierung festgelegt
  * werden). Zus&auml;tzlich werden die Ver&auml;nderungen (Ein/Ausschalten) der
  * E-Eing&auml;nge gez&auml;hlt und in speziellen Z&auml;hler-Feldern gef&uuml;hrt.
  * Diese Z&auml;hler k&ouml;nnen zur Positionsbestimmung von Modellen
  * herangezogen werden (Schlagwort: Impulsr&auml;dchen auf der Antriebswelle).
  * Die erforderlichen Quellen und Objekte sind in javaFish.ZIP zu finden.
  * <p>
  * Organisation:<br>
  * Ulrich M&uuml;ller, D-33100 Paderborn, Lange Wenne 18<br>
  * Fon 05251/56873, Fax 05251/55709<br>
  * eMail: <a href="mailto:ulrich.mueller@owl-online.de">
  * ulrich.mueller@owl-online.de</a><br>
  * Homepage: <a href="www.ftcomputing.de">www.ftcomputing.de</a>
  * </p>
  *
  * @author Ulrich M&uuml;ller, Copyright: &copy; 2001-2003
  * @version 1.1 vom 10.08.03
  *
  */
public class JavaFish {
  private native int jcOpenInterface(int iNr, String PortName);
  private native int jcCloseInterface(int iNr);
  private native int jcGetInput(int iNr, int InputNr);
  private native int jcSetMotor(int iNr, int MotorNr, int Direction);
  private native int jcSetLamp(int iNr, int LampNr, int OnOff);
  private native int jcGetDCB(int iNr, int Index);
  private native void jcSetDCB(int iNr, int Index, int Wert);
  private native void jcSleep(int MilliSec);
  private native boolean jcEscape();
  private int iNr;

  static{
    try {
      System.loadLibrary("javaFish");
    }
    catch (UnsatisfiedLinkError ex){
      System.out.println("javaFish.DLL konnte nicht geladen werden");
    }
  }

  /**
    * Standard-Konstruktor bei nur einem Interface.
    */
  public JavaFish(){
    this(0);
  }

  /**
    * Konstruktor, nur erforderlichen bei mehreren Interfaces.
    * @param ftInstanz die Interface-Nummer (0 bis 3)
    */
  public JavaFish(int ftInstanz){
    iNr = (ftInstanz < 0 || ftInstanz > 3) ? 1 : ftInstanz;
  }

  /**
    * Motor-Zustand <code>OFF = 0</code>
    */
  public static final int OFF = 0;

  /**
    * Motor-Zustand <code>ON = 1</code>
    */
  public static final int ON = 1;

  /**
    * Motor-Zustand <code>LEFT = 1</code>
    */
  public static final int LEFT = 1;

  /**
    * Motor-Zustand <code>RIGHT = 2</code>
    */
  public static final int RIGHT = 2;

  /**
    * Fehlerwert <code>FT_ERROR = 131071</code>,
    */
  public static final int FT_ERROR = 131071;

  /**
    * Abbruchwunsch angemeldet, wenn <code>true</code>,
    * Defaultwert = <code>false</code>
    */
  public boolean emergencyHalt = false;

  /**
    * Legt fest, ob die Analog-Eing&auml;nge EX und EY gescannt werden sollen.
    * @param onOff <b>true</b> f&uuml;r ja, <b>false</b> (default) f&uuml;r nein
    */
  public void setAnalogScan(boolean onOff){
    jcSetDCB(iNr, 7, onOff ? 1 : 0);
  }

  /**
    * Legt fest, ob am Intelligenten Interface ein Erweiterungsmodul
    * angeschlossen ist.
    * @param onOff <b>true</b> f&uuml;r ja, <b>false</b> (default) f&uuml;r nein
    */
  public void setSlave(boolean onOff){
    jcSetDCB(iNr, 4, onOff ? 16 : 8);
  }

  /**
    * legt die Zeit in Millsisekunden zwischen zwei Abfragen des Interface fest.
    * @param pollInterval Zeit zwischen den Abfragen
    */
  public void setPollInterval(int pollInterval){
    jcSetDCB(iNr, 6, pollInterval);
  }

  /**
    * Anpassen der parallelen Interfaces unter Win95/98/Me an die
    * Rechnergeschwindigkeit.<br>
    * Einstellung: 5 (default), Rechner ab Pentium 400 h&ouml;her.<br>
    * Eventuelle Modifikationen sollten vor dem Aufruf von
    * {@link #openInterface} erfolgen.<br>
    * <b>Diese Methode ist nur bei Verwendung von parallelen Interfaces
    * von Bedeutung!</b>
    * @param lptAnalog Faktor f&uuml;r die Analog-Eing&auml;nge
    */
  public void setLPTAnalog(int lptAnalog){
    jcSetDCB(iNr, 3, lptAnalog);
  }

  /**

    * Anpassen der parallelen Interfaces unter Win95/98/Me an die
    * Rechnergeschwindigkeit.<br>
    * Einstellung: 10 (default), Rechner ab Pentium 400 h&ouml;her.<br>
    * Eventuelle Modifikationen sollten vor dem Aufruf von
    * {@link #openInterface} erfolgen.<br>
    * <b>Diese Methode ist nur bei Verwendung von parallelen Interfaces
    * von Bedeutung!</b>
    * @param lptDelay Auslese-Intervall f&uuml;r die digitalen E-Eing&auml;nge
    */
  public void setLPTDelay(int lptDelay){
    jcSetDCB(iNr, 2, lptDelay);
  }

  /**
    * Herstellen der Verbindung zum Interface.
    * @param portName LPT, LPT1 bis LPT3, COM1 bis COM8
    * @return 0, falls Verbindung erfolgreich, sonst {@link #FT_ERROR}
    */
  public int openInterface(String portName){
    emergencyHalt = false;
    return jcOpenInterface(iNr, portName);
  }

  /**
    * Schlie&szlig;en der Verbindung zum Interface.
    * @return 1, falls erfolgreich, sonst anderer Wert
    */
  public int closeInterface(){
    return(jcCloseInterface(iNr));
  }

  /**
    * Liefert die Version der eingesetzten <code>javaFish.DLL</code> zur&uuml;ck.
    * @return Versionsnummer
    */
  public native int getVersion();

  /**
    * Gibt die aktuellen Daten auf die Konsole aus.
    */
  public void showStatus(){
    boolean res;
    System.out.println("Version      : " + getVersion());
    System.out.println("LPTAnalog    : " + jcGetDCB(iNr,3));
    System.out.println("LPTDelay     : " + jcGetDCB(iNr,2));
    res = (jcGetDCB(iNr,4) != 8);
    System.out.println("Slave        : " + res);
    System.out.println("PollInterval : " + jcGetDCB(iNr,6));
    res = (jcGetDCB(iNr,7) != 0);
    System.out.println("AnalogScan   : " + res);
    System.out.println("OutputStatus : " + jcGetDCB(iNr,8));
    System.out.println("InputStatus  : " + jcGetDCB(iNr,9));
    System.out.println("EX           : " + jcGetDCB(iNr,10));
    System.out.println("EY           : " + jcGetDCB(iNr,11));
  }

  /**
    * Schalten der M-Ausg&auml;nge M1 bis M4 (M5 bis M8).
    * @param motorNr Motor-Nummer M1 = 1 bis M4 = 4 (ggf. bis M8 = 8)
    * @param direction Motor-Zustand
    * ({@link #OFF}, {@link #ON}, {@link #LEFT}, {@link #RIGHT})
    * @return Status aller Ausg&auml;nge
    * @see #getOutputs()
    */
  public int setMotor(int motorNr, int direction){
    return jcSetMotor(iNr, motorNr, direction);
  }

  /**
    * Ausschalten aller M-Ausg&auml;nge
    */
  public void clearMotors(){
    jcSetDCB(iNr, 8, 0);
  }

  /**
    * Schalten der M-Ausg&auml;nge M1 bis M4 (M5 bis M8)
    * in &quot;Lampenschaltung&quot; (ein Bein an Erde).
    * @param lampNr Nummer des M-Ausgangs M1 = 1 bis M4 = 4 (ggf. bis M8 = 8)
    * @param onOff <b>true</b> f&uuml;r ein, <b<false</b> f&uuml;r aus
    * @return Status aller Ausg&auml;nge
    * @see #getOutputs()
    */
  public int setLamp(int lampNr, boolean onOff){
    return jcSetLamp(iNr, lampNr, onOff ? 1 : 0);
  }

   /**
    * Liest einen Analog-Eingang aus.
    * @param analogNr Nummer des Analog-Eingangs EX = 0, EY = 1
    * @return Analog-Wert (0 bis 1024)
    */
  public int getAnalog(int analogNr){
    return jcGetDCB(iNr, analogNr+10);
  }

  /**
    * Liest eine Digital-Eingang E1 bis E8 (E9 bis E16) aus.
    * @param inputNr Digital-Eingang E1 = 1 bis E8 = 8 (ggf. bis E16 = 16)
    * @return <b>true</b>, Kontakt geschlossen oder <b>false</b>, Kontakt offen
    */
  public boolean getInput(int inputNr){
    return (jcGetInput(iNr, inputNr) != 0);
  }

  /**
    * Auslesen aller M-Ausg&auml;nge M1 bis M8.<br>
    * Es sind jeweils 2 bit pro Ausgang belegt. Dabei bedeuten:<br>
    * <ul>
    * <li> 01 (das niederwertige bit ist gesetzt): &quot;Linkslauf&quot; </li>
    * <li> 10 (das h&ouml;herwertige bit ist gesetzt): &quot;Rechtslauf&quot; </li>
	* <li> 00 (kein bit ist gesetzt): &quot;aus&quot; </li>
	* <li> beide bits d&uuml;rfen nicht gleichzeitig gesetzt sein </li>
	* </ul>
	* M1: bit 0/1 bis M8: bit 14/15
    * @return Wert aller M-Ausg&auml;nge
    */
  public int getOutputs(){
    return jcGetDCB(iNr, 8);
  }

  /**
    * Setzen aller M-Ausg&auml;nge  M1 bis M8.
    * Es sind jeweils 2 bit pro Ausgang belegt. Dabei bedeuten:<br>
    * <ul>
    * <li> 01 (das niederwertige bit ist gesetzt): &quot;Linkslauf&quot; </li>
    * <li> 10 (das h&ouml;herwertige bit ist gesetzt): &quot;Rechtslauf&quot; </li>
	* <li> 00 (kein bit ist gesetzt): &quot;aus&quot; </li>
	* <li> beide bits d&uuml;rfen nicht gleichzeitig gesetzt sein </li>
	* </ul>
	* M1: bit 0/1 bis M8: bit 14/15
    * @param m Wert aller M-Ausg&auml;nge,
    */
  public void setOutputs(int m){
    jcSetDCB(iNr, 8, m);
  }

  /**
    * Auslesen aller digitalen E-Eing&auml;nge E1 bis E16.
    * Es ist jeweils ein bit pro Ausgang belegt,
    * wobei der Wert von E1 im niedrigstes bit steht.
    * @return Wert aller E-Eing&auml;nge
    */
  public int getInputs(){
    return jcGetDCB(iNr, 9);
  }

  /**
    * L&ouml;schen aller Z&auml;hler,
    * d.h. jeder Z&auml;hler wird auf den Wert 0 gesetzt.
    */
  public void clearCounters(){
    for(int i = 12; i < 28; i++) jcSetDCB(iNr, i, 0);
  }

  /**
    * Setzen eines Z&auml;hlers auf einen Anfangswert.
    * @param counterNr Nummer des Z&auml;hlers (1 bis 8, ggf. bis 16)
    * @param counterValue Anfangswert
    */
  public void setCounter(int counterNr, int counterValue){
    jcSetDCB(iNr, counterNr+11, counterValue);
  }

  /**
    * Auslesen eines aktuellen Z&auml;hler-Wertes
    * @param counterNr Z&auml;hler-Nummer (1 bis 8, ggf. bis 16)
    * @return Wert des Z&auml;hlers
    */
  public int getCounter(int counterNr){
    return jcGetDCB(iNr, counterNr+11);
  }

  /**
    * Anhalten des Programmablaufs um <code>n</code> Millisekunden
    * @param milliSec Dauer der Pause in Millisekunden
    */
  public void pause(int milliSec){
    int dZeit = milliSec;
    while(dZeit>100) {
      if(emergencyHalt || jcEscape()) return;
      jcSleep(100);
      dZeit -= 100;
    }
    jcSleep(dZeit);
  }

  /**
    * Pr&uuml;ft, ob ein bestimmter digitaler E-Eingang geschlossen oder
    * die Escape-Taste gedr&uuml;ckt ist.
    * @param inputNr Nummer der E-Eingangs (E1 = 1 bis E8 = 8 ggf. bis E16 = 16)
    * @return <b>true</b>, E-Eingang ist geschlossen oder Escape-Taste
    * gedr&uuml;ckt, andernfalls <code>false</code>
    */
  public boolean finish(int inputNr){
    return emergencyHalt || jcEscape() || getInput(inputNr);
  }

  /**
    * Pr&uuml;ft, ob die Escape-Taste gedr&uuml;ckt ist.
    * @return <b>true</b>, falls Escape-Taste gedr&uuml;ckt,
    * andernfalls <code>false</code>
    */
  public boolean finish(){
    return emergencyHalt || jcEscape();
  }
}
